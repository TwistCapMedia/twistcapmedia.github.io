To be used for the Bootstrap customizer for the [Bootstrap customizer](http://bootstrap-live-customizer.com/)
